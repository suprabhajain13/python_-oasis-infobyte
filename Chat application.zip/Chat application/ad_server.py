#Chat Application Server side code for advanced

import socket
import threading
from cryptography.fernet import Fernet

class ChatServer:
    def __init__(self, host='127.0.0.1', port=5000):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind((host, port))
        self.server_socket.listen(5)
        self.clients = {}  # Track client usernames and sockets
        self.rooms = {"General": []}  # Chat rooms
        self.key = Fernet.generate_key()
        self.cipher = Fernet(self.key)
        print(f"Server started on {host}:{port}")
        print(f"Encryption key: {self.key.decode()}")

    def broadcast(self, message, room, client_socket=None):
        encrypted_message = self.cipher.encrypt(message.encode())
        for client in self.rooms[room]:
            if client != client_socket:
                try:
                    client.send(encrypted_message)
                except Exception as e:
                    print(f"Error sending message to client: {e}")
                    self.rooms[room].remove(client)
                    client.close()

    def handle_client(self, client_socket, username):
        room = "General"  # Default room
        self.rooms[room].append(client_socket)
        print(f"{username} joined the room {room}")

        while True:
            try:
                message = client_socket.recv(1024)
                if message:
                    decrypted_message = self.cipher.decrypt(message).decode()
                    print(f"Message from {username}: {decrypted_message}")
                    self.broadcast(f"{username}: {decrypted_message}", room, client_socket)
            except Exception as e:
                print(f"Error: {e}")  # Connection issue or client left
                self.rooms[room].remove(client_socket)
                client_socket.close()
                print(f"{username} disconnected from the room {room}")
                break

    def start(self):
        while True:
            client_socket, client_address = self.server_socket.accept()
            print(f"Connection from {client_address}")

            # Ask the client for their username
            client_socket.send(self.cipher.encrypt(b'Enter your username: '))
            username = self.cipher.decrypt(client_socket.recv(1024)).decode()

            threading.Thread(target=self.handle_client, args=(client_socket, username)).start()

if __name__ == "__main__":
    server = ChatServer()
    server.start()
