#Chat Application client side code for advanced

import socket
import threading
from cryptography.fernet import Fernet

class ChatClient:
    def __init__(self, host='127.0.0.1', port=5000, key=None):
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.connect((host, port))
        self.key = key.encode()
        self.cipher = Fernet(self.key)
        self.username = input("Enter your username: ")

        # Send username to the server
        self.client_socket.send(self.cipher.encrypt(self.username.encode()))

        # Start the thread to listen for incoming messages
        receive_thread = threading.Thread(target=self.receive_messages)
        receive_thread.start()

        self.send_messages()

    def receive_messages(self):
        while True:
            try:
                message = self.client_socket.recv(1024)
                if message:
                    decrypted_message = self.cipher.decrypt(message).decode()
                    print(decrypted_message)
            except Exception as e:
                print(f"Error receiving message: {e}")
                self.client_socket.close()
                break

    def send_messages(self):
        while True:
            message = input("")
            if message.lower() == "exit":
                self.client_socket.close()
                break
            encrypted_message = self.cipher.encrypt(message.encode())
            self.client_socket.send(encrypted_message)

if __name__ == "__main__":
    # Use the key printed from the server
    key = input("Enter the encryption key: ")
    ChatClient(key=key)
