#Random Password Generator for advanced

import tkinter as tk
from tkinter import messagebox
import random
import string
import pyperclip  # For clipboard functionality

def generate_password(length, use_letters, use_numbers, use_symbols):
    character_pool = ''
    if use_letters:
        character_pool += string.ascii_letters
    if use_numbers:
        character_pool += string.digits
    if use_symbols:
        character_pool += string.punctuation
    
    if not character_pool:
        raise ValueError("At least one character set must be selected.")
    
    return ''.join(random.choice(character_pool) for _ in range(length))

class PasswordGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Random Password Generator")

        # User input fields
        tk.Label(root, text="Password Length:").grid(row=0, column=0)
        self.length_entry = tk.Entry(root)
        self.length_entry.grid(row=0, column=1)

        self.include_letters = tk.BooleanVar(value=True)
        tk.Checkbutton(root, text="Include Letters", variable=self.include_letters).grid(row=1, columnspan=2)

        self.include_numbers = tk.BooleanVar(value=True)
        tk.Checkbutton(root, text="Include Numbers", variable=self.include_numbers).grid(row=2, columnspan=2)

        self.include_symbols = tk.BooleanVar(value=True)
        tk.Checkbutton(root, text="Include Symbols", variable=self.include_symbols).grid(row=3, columnspan=2)

        tk.Button(root, text="Generate Password", command=self.generate_password).grid(row=4, columnspan=2)
        tk.Button(root, text="Copy to Clipboard", command=self.copy_to_clipboard).grid(row=5, columnspan=2)

        self.password_output = tk.StringVar()
        tk.Entry(root, textvariable=self.password_output, state='readonly').grid(row=6, columnspan=2)

    def generate_password(self):
        try:
            length = int(self.length_entry.get())
            password = generate_password(length, self.include_letters.get(), 
                                         self.include_numbers.get(), self.include_symbols.get())
            self.password_output.set(password)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def copy_to_clipboard(self):
        password = self.password_output.get()
        if password:
            pyperclip.copy(password)
            messagebox.showinfo("Copied!", "Password copied to clipboard.")

if __name__ == "__main__":
    root = tk.Tk()
    app = PasswordGeneratorApp(root)
    root.mainloop()
